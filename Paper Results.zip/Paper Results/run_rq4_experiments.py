#!/usr/bin/env python3
"""
RQ4 runner: practical scalability limits of COORDINATE 2.0.

RQ4 focuses on execution time, memory usage, event throughput, and trace size as
simulation duration, fleet size, and workload increase. Each run is executed in
an isolated Python subprocess so peak RSS can be measured per simulation.

Default campaign per hardware profile:
    3 durations x 3 workload levels x 3 fleet sizes x 1 mechanism (DA) x
    5 repetitions = 135 runs.

    The CE baseline has already been completed. It can still be requested
    explicitly with --coord-labels CE,DA if the full matrix must be rebuilt.

Run examples:
    python "Paper Results/run_rq4_experiments.py" --dry-run
    nohup python "Paper Results/run_rq4_experiments.py" > "Paper Results/RQ4/rq4.log" 2>&1 &

Resume behavior:
    Completed runs are detected from RQ4/runs.csv.
    Re-launching with more repetitions skips completed repetitions and runs only
    missing or previously failed ones. Use --force to intentionally re-run all.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import platform
import re
import subprocess
import sys
import time
from itertools import product
from pathlib import Path
from typing import Any

from paper_experiment_utils import (
    COORD_TO_ARCH,
    PAPER_ROOT,
    PROJECT_ROOT,
    analyze_log,
    build_paper_daily_phases,
    cleanup_transient_artifacts,
    config_with_paths,
    completed_run_ids,
    ensure_result_dirs,
    file_size_mb,
    malicious_count,
    read_rows,
    replace_row,
    safe_float,
    summarise_rows,
    write_json,
    write_rows,
)


RESULTS_ROOT = PAPER_ROOT / "RQ4"
DEFAULT_SIM_DAYS = [1, 7, 30]
DEFAULT_ITEM_SPAWNING_TIMES = [150, 120, 90]
DEFAULT_N_ROBOTS = [10, 20, 30]
DEFAULT_COORD_LABELS = ["DA"]
SUBPROCESS_MARKER = "__RQ4_RESULT__"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run RQ4 scalability experiments.")
    parser.add_argument("--repetitions", type=int, default=5, help="Repetitions per configuration.")
    parser.add_argument("--base-seed", type=int, default=20260604, help="Base random seed.")
    parser.add_argument("--fail-prob", type=float, default=0.66, help="Baseline agent failure probability.")
    parser.add_argument("--msg-loss", type=float, default=0.10, help="Baseline message loss probability.")
    parser.add_argument("--malicious-ratio", type=float, default=0.33, help="Malicious-agent ratio.")
    parser.add_argument("--stress-multiplier", type=float, default=1.2, help="Paper stress-window multiplier.")
    parser.add_argument(
        "--coord-labels",
        default=",".join(DEFAULT_COORD_LABELS),
        help="Comma-separated mechanisms to include. Defaults to DA; use CE,DA only to rebuild the full matrix.",
    )
    parser.add_argument(
        "--machine-label",
        default=None,
        help="Short label for the computer running this shard, e.g. mac or workstation.",
    )
    parser.add_argument("--shard-count", type=int, default=1, help="Number of machines/shards used for RQ4.")
    parser.add_argument("--shard-index", type=int, default=1, help="1-based index of the shard to run on this machine.")
    parser.add_argument("--quick", action="store_true", help="Small smoke campaign for checking the runner.")
    parser.add_argument("--dry-run", action="store_true", help="Print the campaign design without running simulations.")
    parser.add_argument("--force", action="store_true", help="Re-run even if the run is already marked ok in runs.csv.")
    parser.add_argument("--limit", type=int, default=None, help="Run only the first N run instances.")
    parser.add_argument("--fail-fast", action="store_true", help="Stop immediately if a run fails.")
    return parser.parse_args()


def sanitize_label(value: str) -> str:
    label = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip().lower()).strip("-_")
    return label or "machine"


def default_machine_label() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "mac"
    if system == "windows":
        return "windows"
    if system == "linux":
        return "linux"
    return sanitize_label(platform.node() or system or "machine")


def machine_label(args: argparse.Namespace) -> str:
    return sanitize_label(args.machine_label or default_machine_label())


def hardware_metadata(label: str) -> dict[str, Any]:
    return {
        "machine_label": label,
        "machine_node": platform.node(),
        "machine_system": platform.system(),
        "machine_release": platform.release(),
        "machine_platform": platform.platform(),
        "machine_processor": platform.processor(),
        "machine_cpu_count": os.cpu_count(),
        "python_version": platform.python_version(),
    }


def selected_coord_labels(args: argparse.Namespace) -> list[str]:
    labels = [label.strip().upper() for label in args.coord_labels.split(",") if label.strip()]
    unknown = [label for label in labels if label not in COORD_TO_ARCH]
    if unknown:
        raise ValueError(f"Unknown coordination labels: {', '.join(unknown)}")
    if not labels:
        raise ValueError("At least one coordination label is required.")
    return labels


def validate_shard_args(args: argparse.Namespace) -> None:
    if args.shard_count < 1:
        raise ValueError("--shard-count must be >= 1")
    if args.shard_index < 1 or args.shard_index > args.shard_count:
        raise ValueError("--shard-index must be between 1 and --shard-count")


def build_campaign_rows(args: argparse.Namespace) -> list[dict[str, Any]]:
    if args.quick:
        sim_days_values = [1]
        item_spawning_times = [150]
        n_robots_values = [10]
        coord_labels = selected_coord_labels(args)
        repetitions = 1 if args.repetitions == 5 else args.repetitions
    else:
        sim_days_values = DEFAULT_SIM_DAYS
        item_spawning_times = DEFAULT_ITEM_SPAWNING_TIMES
        n_robots_values = DEFAULT_N_ROBOTS
        coord_labels = selected_coord_labels(args)
        repetitions = args.repetitions

    rows: list[dict[str, Any]] = []
    combo_idx = 0
    label = machine_label(args)
    for sim_days, item_spawn, n_robots, coord_label in product(
        sim_days_values,
        item_spawning_times,
        n_robots_values,
        coord_labels,
    ):
        combo_idx += 1
        for rep in range(1, repetitions + 1):
            rows.append({
                "combo_idx": combo_idx,
                "rep": rep,
                "seed": args.base_seed + combo_idx * 1000 + rep,
                "machine_label": label,
                "coord_label": coord_label,
                "architecture": COORD_TO_ARCH[coord_label],
                "sim_days": sim_days,
                "item_spawning_time": item_spawn,
                "n_robots": n_robots,
                "malicious_ratio": args.malicious_ratio,
                "n_malicious": malicious_count(n_robots, args.malicious_ratio),
                "fail_prob": args.fail_prob,
                "msg_loss_prob": args.msg_loss,
            })
    return rows


def shard_rows(rows: list[dict[str, Any]], args: argparse.Namespace) -> list[dict[str, Any]]:
    validate_shard_args(args)
    if args.shard_count == 1:
        return rows
    shard_offset = args.shard_index - 1
    return [
        row
        for idx, row in enumerate(rows)
        if idx % args.shard_count == shard_offset
    ]


def campaign(args: argparse.Namespace) -> list[dict[str, Any]]:
    rows = shard_rows(build_campaign_rows(args), args)
    return rows[: args.limit] if args.limit else rows


def run_id(params: dict[str, Any]) -> str:
    return (
        f"{params['machine_label']}_c{params['combo_idx']:03d}_r{params['rep']:02d}_"
        f"{params['coord_label']}_days{params['sim_days']}_"
        f"spawn{params['item_spawning_time']}_bots{params['n_robots']}"
    )


def run_subprocess(cfg_path: Path) -> dict[str, Any]:
    code = f"""
import json
import resource
import sys
from pathlib import Path
from sim import simulator

cfg_path = Path(sys.argv[1])
logfile, wall_time, event_count = simulator.run(str(cfg_path))
rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
if sys.platform == "darwin":
    max_rss_mb = rss / (1024 * 1024)
else:
    max_rss_mb = rss / 1024
print("{SUBPROCESS_MARKER}" + json.dumps({{
    "logfile": logfile,
    "wall_time_s": wall_time,
    "event_count": event_count,
    "max_rss_mb": max_rss_mb,
}}))
"""
    proc = subprocess.run(
        [sys.executable, "-c", code, str(cfg_path)],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        tail = "\n".join((proc.stdout + "\n" + proc.stderr).splitlines()[-30:])
        raise RuntimeError(f"subprocess failed with code {proc.returncode}\n{tail}")

    result_lines = [line for line in proc.stdout.splitlines() if line.startswith(SUBPROCESS_MARKER)]
    if not result_lines:
        tail = "\n".join(proc.stdout.splitlines()[-30:])
        raise RuntimeError(f"subprocess completed but no result marker was found\n{tail}")
    return json.loads(result_lines[-1].removeprefix(SUBPROCESS_MARKER))


def run_campaign(args: argparse.Namespace) -> None:
    label = machine_label(args)
    hardware = hardware_metadata(label)
    all_combos = build_campaign_rows(args)
    shard_combos = shard_rows(all_combos, args)
    combos = shard_combos[: args.limit] if args.limit else shard_combos
    design = {
        "research_question": "RQ4",
        "repetitions": args.repetitions,
        "total_runs": len(combos),
        "full_campaign_runs": len(all_combos),
        "shard_runs_before_limit": len(shard_combos),
        "machine_label": label,
        "machine_metadata": hardware,
        "shard_count": args.shard_count,
        "shard_index": args.shard_index,
        "sim_days": [1] if args.quick else DEFAULT_SIM_DAYS,
        "item_spawning_times": [150] if args.quick else DEFAULT_ITEM_SPAWNING_TIMES,
        "n_robots": [10] if args.quick else DEFAULT_N_ROBOTS,
        "coordination_mechanisms": selected_coord_labels(args),
        "malicious_ratio": args.malicious_ratio,
        "fail_prob": args.fail_prob,
        "msg_loss": args.msg_loss,
        "daily_stress_window": [12, 24],
        "stress_multiplier": args.stress_multiplier,
        "purpose": "Measure execution time, peak RSS, event throughput, and trace size.",
    }
    print("=" * 80)
    print("RQ4 SCALABILITY CAMPAIGN")
    print("=" * 80)
    print(design)
    print("=" * 80)

    if args.dry_run:
        print("Dry run only. No simulations launched.")
        return

    raw_logs_dir, configs_dir = ensure_result_dirs(RESULTS_ROOT)
    machine_raw_logs_dir = raw_logs_dir / label
    machine_configs_dir = configs_dir / label
    machine_raw_logs_dir.mkdir(parents=True, exist_ok=True)
    machine_configs_dir.mkdir(parents=True, exist_ok=True)

    rows = [] if args.force else read_rows(RESULTS_ROOT / "runs.csv")
    errors = [] if args.force else read_rows(RESULTS_ROOT / "errors.csv")
    completed = completed_run_ids(rows)
    started_at = time.time()

    for idx, params in enumerate(combos, start=1):
        rid = run_id(params)
        if rid in completed and not args.force:
            print(f"[{idx}/{len(combos)}] {rid} already completed; skipping", flush=True)
            continue

        run_dir = machine_raw_logs_dir / rid
        run_dir.mkdir(parents=True, exist_ok=True)
        logfile = run_dir / "simulation_log.csv"
        cfg_path = machine_configs_dir / f"{rid}.json"
        phases = build_paper_daily_phases(
            sim_days=params["sim_days"],
            base_fail_prob=params["fail_prob"],
            base_msg_loss=params["msg_loss_prob"],
            base_recovery_time=1800.0,
            n_malicious=params["n_malicious"],
            item_spawning_time=params["item_spawning_time"],
            stress_multiplier=args.stress_multiplier,
        )
        cfg = config_with_paths(
            results_root=RESULTS_ROOT,
            logfile=logfile,
            architecture=params["architecture"],
            seed=params["seed"],
            sim_days=params["sim_days"],
            updates={
                "MACHINE_LABEL": label,
                "MACHINE_METADATA": hardware,
                "N_ROBOTS": params["n_robots"],
                "N_MALICIOUS": params["n_malicious"],
                "FAIL_PROB": params["fail_prob"],
                "COMM_FAIL_PROB": params["msg_loss_prob"],
                "ITEM_SPAWNING_TIME": params["item_spawning_time"],
            },
            phases=phases,
        )
        write_json(cfg_path, cfg)

        print(f"[{idx}/{len(combos)}] {rid}", flush=True)
        status = "ok"
        error_message = ""
        subprocess_metrics = {
            "wall_time_s": math.nan,
            "event_count": math.nan,
            "max_rss_mb": math.nan,
        }
        metrics: dict[str, Any] = {}
        had_previous_error = any(error.get("run_id") == rid for error in errors)
        errors = [error for error in errors if error.get("run_id") != rid]
        if had_previous_error and logfile.exists() and not args.force:
            print("  previous error found; removing stale log and re-running", flush=True)
            logfile.unlink()

        try:
            if logfile.exists() and not args.force:
                print("  existing log found; analysing without re-running", flush=True)
            else:
                subprocess_metrics = run_subprocess(cfg_path)
            metrics = analyze_log(logfile, cfg["SIM_TIME"])
        except BaseException as exc:
            if isinstance(exc, KeyboardInterrupt):
                raise
            status = "error"
            error_message = str(exc) or exc.__class__.__name__
            errors.append({
                **params,
                "run_id": rid,
                "config_path": str(cfg_path),
                "logfile": str(logfile),
                "error": error_message,
            })
            print(f"  ERROR: {error_message}", flush=True)
            if args.fail_fast:
                raise

        wall_time = safe_float(subprocess_metrics.get("wall_time_s"))
        event_count = safe_float(subprocess_metrics.get("event_count"))
        row = {
            "run_id": rid,
            "status": status,
            "error": error_message,
            "config_path": str(cfg_path),
            "logfile": str(logfile),
            "machine_label": label,
            "shard_count": args.shard_count,
            "shard_index": args.shard_index,
            **hardware,
            "coord_label": params["coord_label"],
            "architecture": params["architecture"],
            "rep": params["rep"],
            "seed": params["seed"],
            "sim_days": params["sim_days"],
            "item_spawning_time": params["item_spawning_time"],
            "n_robots": params["n_robots"],
            "malicious_ratio": params["malicious_ratio"],
            "n_malicious": params["n_malicious"],
            "fail_prob": params["fail_prob"],
            "msg_loss_prob": params["msg_loss_prob"],
            "wall_time_s": wall_time,
            "event_count": event_count,
            "events_per_wall_s": event_count / wall_time if wall_time and not math.isnan(wall_time) else math.nan,
            "max_rss_mb": subprocess_metrics.get("max_rss_mb"),
            "config_size_kb": cfg_path.stat().st_size / 1024 if cfg_path.exists() else 0.0,
            "total_output_size_mb": file_size_mb(logfile)
            + file_size_mb(logfile.with_name(logfile.stem + "_overhead.csv")),
            **metrics,
        }
        rows = replace_row(rows, row)
        machine_rows = [existing for existing in rows if existing.get("machine_label") == label]

        write_rows(RESULTS_ROOT / "runs.csv", rows)
        write_rows(RESULTS_ROOT / f"runs_{label}.csv", machine_rows)
        if errors:
            write_rows(RESULTS_ROOT / "errors.csv", errors)

    summary = summarise_rows(
        rows,
        group_fields=["machine_label", "coord_label", "architecture", "sim_days", "item_spawning_time", "n_robots"],
        metric_fields=[
            "wall_time_s",
            "event_count",
            "events_per_wall_s",
            "max_rss_mb",
            "trace_rows",
            "trace_size_mb",
            "overhead_trace_size_mb",
            "total_output_size_mb",
            "created",
            "delivered",
            "avg_latency_s",
            "p95_latency_s",
            "adapt_checks",
        ],
    )
    write_rows(RESULTS_ROOT / "scalability_summary.csv", summary)
    machine_summary = summarise_rows(
        [row for row in rows if row.get("machine_label") == label],
        group_fields=["machine_label", "coord_label", "architecture", "sim_days", "item_spawning_time", "n_robots"],
        metric_fields=[
            "wall_time_s",
            "event_count",
            "events_per_wall_s",
            "max_rss_mb",
            "trace_rows",
            "trace_size_mb",
            "overhead_trace_size_mb",
            "total_output_size_mb",
            "created",
            "delivered",
            "avg_latency_s",
            "p95_latency_s",
            "adapt_checks",
        ],
    )
    write_rows(RESULTS_ROOT / f"scalability_summary_{label}.csv", machine_summary)
    cleanup_transient_artifacts(RESULTS_ROOT)

    print("=" * 80)
    print(f"RQ4 campaign completed in {time.time() - started_at:.2f}s wall-clock.")
    print(f"Run-level CSV:   {RESULTS_ROOT / 'runs.csv'}")
    print(f"Machine CSV:     {RESULTS_ROOT / f'runs_{label}.csv'}")
    print(f"Summary CSV:     {RESULTS_ROOT / 'scalability_summary.csv'}")
    print(f"Machine summary: {RESULTS_ROOT / f'scalability_summary_{label}.csv'}")
    print("=" * 80)


if __name__ == "__main__":
    run_campaign(parse_args())
